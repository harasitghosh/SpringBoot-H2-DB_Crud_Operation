package com.example.Employee;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService empservice;
	

	@GetMapping("/employees")
	public ArrayList<Employee> getAllEmployee()
	{
		return empservice.getAllEmployee();
	}
	
	
	@PostMapping("/add")
	public void addEmployee(@RequestBody Employee e)
	{
		empservice.addEmployee(e);
	}
	
	@DeleteMapping("/del")
	public void delEmployee(@PathVariable int id)
	{
		empservice.delEmployee(id);
	}
	
	@PutMapping("/update")
	public void updateEmployee(@RequestBody Employee e , @PathVariable int id)
	{
		empservice.updateEmployee(e,id);
	}
	

}

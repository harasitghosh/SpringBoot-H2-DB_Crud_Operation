package com.example.Employee;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepo emp;
	
	public ArrayList<Employee> getAllEmployee(){
		
		ArrayList<Employee>emps = new ArrayList<Employee>();
		emp.findAll().forEach(Employee ->emps.add(Employee));
		return emps;
	}
	
	public void addEmployee(Employee e)
	{
		emp.save(e);
	}
	
	public void delEmployee(int id)
	{
		emp.deleteById(id);
		
	}
	
	public void updateEmployee(Employee e, int id)
	{
		ArrayList<Employee> emps = this.getAllEmployee();
		for(Employee e1:emps)
		{
			if(e1.getId()==id) {
				//emps.remove(e1);
				//emps.add(e);
				//e1.setName(e.getName());
				//e1.setSalary(e.getSalary());
				emp.delete(e1);
				emp.save(e);
			}
		}
	}
	
}
